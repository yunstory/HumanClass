package com.human.shop;

public class KoreanExample {

	public static void main(String[] args) {
		
		Korean abc = new Korean();
		
		System.out.println("name" + abc.name);
		System.out.println("ssn" + abc.ssn);
		System.out.println("nation" + abc.nation);
		System.out.println("num" + abc.num);
		System.out.println("height" + abc.height);
		

	}

}
