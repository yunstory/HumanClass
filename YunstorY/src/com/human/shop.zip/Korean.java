package com.human.shop;

public class Korean {

	
	String name = "lee";
	String ssn = "woman";
	String nation = "korea";
	int num = 112;
	double height = 123.45;
	
}
