package com.human.shop;

public class CarExample {
	public static void main(String[] args) {
		
	
	
	Car dream = new Car();
	
	System.out.println("company:" + dream.company);
	System.out.println("model:" + dream.model);
	System.out.println("color:" + dream.color);
	System.out.println("maxSpeed:" + dream.maxSpeed);
	System.out.println("maxPeople:" + dream.maxPeople);
	
	
	
}
}
