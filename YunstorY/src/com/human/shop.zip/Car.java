package com.human.shop;

public class Car {
	
	String company = "hyundal";
	String model = "genesisgv80";
	String color = "PN7";
	int maxSpeed = 500;
	int maxPeople = 5;

}
