package com.human.shop;

public class HairExample {

	public static void main(String[] args) {
		
		
		Hair abc = new Hair ();
		
		abc.name = "yuns";
		abc.ssn = "lady";
		abc.time = 14;
		abc.style = "cut";
		abc.length = 5;
		
		System.out.println("name:" + abc.name);
		System.out.println("ssn:" + abc.ssn);
		System.out.println("style:" + abc.style);
		System.out.println("length:" + abc.length);

		
		

	}

}
