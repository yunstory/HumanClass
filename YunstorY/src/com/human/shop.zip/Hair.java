package com.human.shop;

public class Hair {

	String name = "";
	String ssn = "";
	int time = 0;
	String style = "";
	int length = 0;
	
}
